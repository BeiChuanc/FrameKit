import { useEffect, useState } from 'react';

export const tools = {
  sheet: { label: '序列帧', title: '视频转序列帧表', description: '裁剪片段、提取画面，再导出游戏和动画所需的序列帧资源。', outputs: ['精灵图 PNG', 'GIF', '透明帧 ZIP', 'Spine'] },
  cutout: { label: '背景抠图', title: '图片背景抠图', description: '点选图片中的背景色，实时调整边缘并导出透明 PNG。', outputs: ['背景取色', '边缘优化', '透明 PNG'] },
  resize: { label: '图片尺寸', title: '批量调整图片尺寸', description: '为一组图片设定目标尺寸，预览缩放结果并批量导出。', outputs: ['JPG', 'PNG', 'WebP'] },
  compress: { label: '图片压缩', title: '批量压缩图片', description: '调整格式和压缩质量，比较文件体积及画面效果。', outputs: ['JPG', 'PNG', 'WebP'] },
} as const;

export type AppMode = keyof typeof tools;
type Theme = 'lime' | 'amber';

export function WorkbenchHeader({ mode, onModeChange }: {
  mode: AppMode;
  onModeChange: (mode: AppMode) => void;
}) {
  const [theme, setTheme] = useState<Theme>(() => localStorage.getItem('framekit-theme') === 'amber' ? 'amber' : 'lime');
  const tool = tools[mode];
  const desktop = 'chrome' in window && Boolean((window.chrome as { webview?: unknown })?.webview);

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    localStorage.setItem('framekit-theme', theme);
  }, [theme]);

  return (
    <>
      <header className="workbench-header">
        <div className="workbench-top">
          <button className="workbench-brand" type="button" onClick={() => onModeChange('sheet')} aria-label="帧工坊首页">
            <span className="brand-icon" aria-hidden="true"><i /></span>
            <span>帧工坊<small>FRAMEKIT</small></span>
          </button>
          <div className="workbench-controls">
            <span className="local-indicator"><i />{desktop ? 'Windows · 本地处理' : 'Web · 本地处理'}</span>
            <div className="theme-switch" role="group" aria-label="界面主题">
              <button type="button" aria-pressed={theme === 'lime'} onClick={() => setTheme('lime')}><i />青柠</button>
              <button type="button" aria-pressed={theme === 'amber'} onClick={() => setTheme('amber')}><i />琥珀</button>
            </div>
          </div>
        </div>
        <nav className="tool-nav" aria-label="工作区工具">
          {(Object.keys(tools) as AppMode[]).map((item) => (
            <button className="tool-tab" key={item} type="button" aria-pressed={mode === item} onClick={() => onModeChange(item)}>
              <i className={`tool-icon tool-icon--${item}`} aria-hidden="true" />{tools[item].label}
            </button>
          ))}

        </nav>
      </header>

      <section className="workbench-hero">
        <div className="workbench-hero__copy">
          <h1>{tool.title}</h1>
          <p>{tool.description}</p>
          <ul className="output-tags" aria-label="工具能力">
            {tool.outputs.map((output) => <li key={output}>{output}</li>)}
          </ul>
        </div>
        <div className={`timeline-art timeline-art--${mode}`} aria-hidden="true">
          <div className="timeline-art__ruler" />
          <div className="timeline-art__strip">
            <div className="timeline-art__frame"><i /></div>
            <div className="timeline-art__frame is-selected"><i /></div>
            <div className="timeline-art__frame"><i /></div>
            <div className="timeline-art__frame"><i /></div>
          </div>
          <div className="timeline-art__cursor" />
        </div>
      </section>
    </>
  );
}
