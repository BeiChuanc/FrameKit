# 帧工坊 FrameKit V1.0.5

柠檬奶昔

- **Windows 版**：运行 `FrameKit.exe`。支持 Windows x64，使用 Microsoft Edge WebView2 Runtime。
- **Web 版**：将 `FrameKit-Web.zip` 解压到静态网站目录，通过 HTTP(S) 打开。源码目录可执行 `npm ci`、`npm run dev` 开启本地预览。
- **处理流程**：拖入本地视频，设置裁剪范围、片段和帧率，提取参考帧后生成序列图。可选取背景色进行抠像，也可直接导出普通帧。支持 PNG 精灵图、GIF、透明帧 ZIP 和 Spine 资源 ZIP。另有图片抠图、批量缩放和批量压缩工具。
- **性能**：视频和图片在本机处理。长视频、较高帧率或大分辨率会增加内存开销，建议先缩短片段或调整裁剪范围。

## 从源码构建

需要 Node.js、npm、Windows x64 和 .NET 10 SDK。执行 `npm ci`、`npm test`、`npm run package`。`npm run build` 可单独构建 `dist` 中的静态 Web 文件。发行产物在 `release` 中。

许可证与上游来源见 `LICENSE` 和 `NOTICE.txt`。
