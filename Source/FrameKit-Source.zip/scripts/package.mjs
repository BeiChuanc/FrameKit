import { spawnSync } from 'node:child_process';
import { copyFile, mkdir, readdir, readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import JSZip from 'jszip';

async function include(zip, source, target = source) {
  for (const entry of await readdir(source, { withFileTypes: true })) {
    if (entry.isDirectory()) await include(zip, join(source, entry.name), `${target}${entry.name}/`);
    else if (entry.isFile()) await file(zip, join(source, entry.name), target + entry.name);
  }
}

async function file(zip, source, name = source) {
  zip.file(name, await readFile(source));
}

const web = new JSZip();
await include(web, 'dist', '');
await file(web, 'LICENSE');
await mkdir('desktop/obj', { recursive: true });
await mkdir('release', { recursive: true });
await writeFile('desktop/obj/web.zip', await web.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' }));

const publish = spawnSync('dotnet', ['publish', 'desktop/FrameKit.csproj', '-c', 'Release', '-o', 'desktop/obj/publish'], { stdio: 'inherit' });
if (publish.error) throw publish.error;
if (publish.status !== 0) process.exit(publish.status ?? 1);
await copyFile('desktop/obj/publish/FrameKit.exe', 'release/FrameKit.exe');
await file(web, 'NOTICE.txt');
await writeFile('release/FrameKit-Web.zip', await web.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' }));

const source = new JSZip();
for (const folder of ['src', 'public', 'scripts']) await include(source, folder, folder + '/');
for (const name of ['LICENSE', 'NOTICE.txt', 'README.md', 'package.json', 'package-lock.json', 'index.html', 'tsconfig.json', 'tsconfig.app.json', 'tsconfig.node.json', 'vite.config.ts', 'desktop/FrameKit.csproj', 'desktop/Program.cs', 'desktop/FrameKit.ico']) {
  await file(source, name);
}
await writeFile('release/FrameKit-Source.zip', await source.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' }));
await copyFile('NOTICE.txt', 'release/NOTICE.txt');
await copyFile('LICENSE', 'release/LICENSE');
