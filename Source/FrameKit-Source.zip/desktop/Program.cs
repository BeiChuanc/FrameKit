using System.IO.Compression;
using System.Reflection;
using System.Security.Cryptography;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace FrameKit;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new WorkbenchWindow());
    }
}

internal sealed class WorkbenchWindow : Form
{
    private const string LocalHost = "framekit.local";

    private readonly WebView2 web = new() { Dock = DockStyle.Fill, DefaultBackgroundColor = Color.FromArgb(17, 19, 19) };
    private readonly Label loading = new()
    {
        Dock = DockStyle.Fill, Text = "正在启动帧工坊…", TextAlign = ContentAlignment.MiddleCenter,
        ForeColor = Color.Gainsboro, BackColor = Color.FromArgb(17, 19, 19)
    };

    public WorkbenchWindow()
    {
        Text = "帧工坊 · FrameKit";
        Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath);
        ClientSize = new Size(1220, 844);
        MinimumSize = new Size(740, 550);
        StartPosition = FormStartPosition.CenterScreen;
        BackColor = loading.BackColor;
        Controls.Add(web);
        Controls.Add(loading);
        loading.BringToFront();
        Shown += async (_, _) => await LoadWorkbench();
    }

    private async Task LoadWorkbench()
    {
        try
        {
            var data = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "FrameKit");
            var assets = await Task.Run(() => InstallAssets(data));
            if (IsDisposed) return;

            var environment = await CoreWebView2Environment.CreateAsync(userDataFolder: Path.Combine(data, "WebView"));
            if (IsDisposed) return;
            await web.EnsureCoreWebView2Async(environment);
            if (IsDisposed) return;

            var core = web.CoreWebView2;
            core.SetVirtualHostNameToFolderMapping(LocalHost, assets, CoreWebView2HostResourceAccessKind.DenyCors);
            core.Settings.AreDefaultContextMenusEnabled = false;
            core.Settings.AreDevToolsEnabled = false;
            core.NavigationStarting += (_, e) =>
            {
                if (!Uri.TryCreate(e.Uri, UriKind.Absolute, out var uri) || uri.Host != LocalHost || uri.Scheme != Uri.UriSchemeHttps)
                    e.Cancel = true;
            };
            core.NewWindowRequested += (_, e) => e.Handled = true;
            core.NavigationCompleted += (_, e) =>
            {
                if (e.IsSuccess) loading.Hide();
                else loading.Text = $"工作区加载失败（{e.WebErrorStatus}）。请关闭窗口后重试。";
            };
            core.Navigate($"https://{LocalHost}/index.html");
        }
        catch (WebView2RuntimeNotFoundException)
        {
            if (!IsDisposed) loading.Text = "需要安装 Microsoft Edge WebView2 Runtime，安装完成后再打开帧工坊。";
        }
        catch (Exception error)
        {
            if (!IsDisposed) loading.Text = $"帧工坊启动失败。{Environment.NewLine}{error.Message}";
        }
    }

    private static string InstallAssets(string data)
    {
        using var archiveStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("FrameKit.Web")
            ?? throw new InvalidOperationException("找不到内置的工作区资源。");
        var hash = Convert.ToHexString(SHA256.HashData(archiveStream))[..24];
        archiveStream.Position = 0;
        var assets = Path.Combine(data, "App", hash);
        if (Directory.Exists(assets)) return assets;

        var staging = assets + "-" + Guid.NewGuid().ToString("N");
        try
        {
            Directory.CreateDirectory(staging);
            using var archive = new ZipArchive(archiveStream, ZipArchiveMode.Read);
            archive.ExtractToDirectory(staging);
            try
            {
                Directory.Move(staging, assets);
            }
            catch (IOException) when (Directory.Exists(assets))
            {
                // Another launch unpacked the same embedded version.
            }
            return assets;
        }
        finally
        {
            if (Directory.Exists(staging))
            {
                // The staging directory is a newly generated child of the app's private cache.
                Directory.Delete(staging, recursive: true);
            }
        }
    }
}
