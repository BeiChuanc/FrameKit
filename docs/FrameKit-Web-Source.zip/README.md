# 帧工坊 FrameKit Web V1.0.5

运行 `npm ci` 安装依赖，`npm run dev` 启动开发服务，`npm test` 运行测试，`npm run build` 生成 `dist/`。

许可证和版本来源见 `LICENSE` 与 `NOTICE.txt`。
